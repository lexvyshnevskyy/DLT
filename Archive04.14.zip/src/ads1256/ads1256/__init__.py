from .waveshare import AdsData
